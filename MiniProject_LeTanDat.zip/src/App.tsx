import CvProject from './components/myCV'
import './App.css'

function App() {
 

  return (
    <>
           <CvProject />
           
    </>
  )
}

export default App
